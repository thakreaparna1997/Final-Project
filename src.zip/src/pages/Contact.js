import React, { Component } from "react";
import "./as.css";



const nameRegex = RegExp(
    /^[a-zA-Z]*$/
);

const emailRegex = RegExp(
    /^[a-zA-Z0-9.!#$%&’+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+[com,org,in]+)$/
);
const numberRegex = RegExp(
    /^[0-9]*$/
);

const formValid = ({ formErrors, ...rest }) => {
    let valid = true;

    // validate form errors being empty
    Object.values(formErrors).forEach(val => {
        val.length > 0 && (valid = false);
    });

    // validate the form was filled out
    Object.values(rest).forEach(val => {
        val === null && (valid = false);
    });

    return valid;
};

class Contact extends Component {
    constructor(props) {
        super(props);

        this.state = {
            firstName: null,
            lastName: null,
            email: null,
            number:null,

            formErrors: {
                firstName: "",
                lastName: "",
                email: "",
                number:"",

            }
        };
    }

    handleSubmit = e => {
        e.preventDefault();

        if (formValid(this.state)) {
            console.log(`
        --SUBMITTING--
        First Name: ${this.state.firstName}
        Last Name: ${this.state.lastName}
        Email: ${this.state.email}
        Number:${this.state.number}
      `);
        } else {
            console.error("FORM INVALID - DISPLAY ERROR MESSAGE");
        }
    };

    handleChange = e => {
        e.preventDefault();
        const { name, value } = e.target;
        let formErrors = { ...this.state.formErrors };

        switch (name) {
            case "firstName":
                formErrors.firstName =nameRegex.test(value)&&value.length > 2
                ? ""
                : "invalid firstname address";
                break;
            case "lastName":
                formErrors.lastName =nameRegex.test(value)&&value.length > 2
                ? ""
                : "invalid lastname address";
                break;
            case "email":
                formErrors.email = emailRegex.test(value)
                    ? ""
                    : "invalid email address";
                break;
            case "number":
                formErrors.number =numberRegex.test(value)&&value.length > 9
                ? ""
                : "invalid mobile number address";
                break;

            default:
                break;
        }

        this.setState({ formErrors, [name]: value }, () => console.log(this.state));
    };

    render() {
        const { formErrors } = this.state;

        return (
          <div className="body1">
            
                <div className="form-wrapper">
                    <h1>Contact Us</h1>
                    <form onSubmit={this.handleSubmit} noValidate>
                        <div className="firstName">
                            <label htmlFor="firstName">First Name</label>
                            <input
                                className={formErrors.firstName.length > 0 ? "error" : null}
                                placeholder="First Name"
                                type="text"
                                name="firstName"
                                noValidate
                                onChange={this.handleChange}
                            />
                            {formErrors.firstName.length > 0 && (
                                <span className="errorMessage">{formErrors.firstName}</span>
                            )}
                        </div>
                        <div className="lastName">
                            <label htmlFor="lastName">Last Name</label>
                            <input
                                className={formErrors.lastName.length > 0 ? "error" : null}
                                placeholder="Last Name"
                                type="text"
                                name="lastName"
                                noValidate
                                onChange={this.handleChange}
                            />
                            {formErrors.lastName.length > 0 && (
                                <span className="errorMessage">{formErrors.lastName}</span>
                            )}
                        </div>
                        <div className="email">
                            <label htmlFor="email">Email</label>
                            <input
                                className={formErrors.email.length > 0 ? "error" : null}
                                placeholder="Email"
                                type="email"
                                name="email"
                                noValidate
                                onChange={this.handleChange}
                            />
                            {formErrors.email.length > 0 && (
                                <span className="errorMessage">{formErrors.email}</span>
                            )}
                        </div>
                        <div className="email">
                            <label htmlFor="number">Contact Number</label>
                            <input
                                className={formErrors.number.length > 0 ? "error" : null}
                                placeholder="10 digit mobile number"
                                type="number"
                                name="number"
                                noValidate
                                onChange={this.handleChange}
                            />
                            {formErrors.number.length > 0 && (
                                <span className="errorMessage">{formErrors.number}</span>
                            )}
                        </div>
                        
                        <div className="password">
                            <label htmlFor="password"> Message</label>
                            <textarea placeholder="Write Your Message Here"></textarea>
                        </div>
                        <div className="createAccount">
                        <form method="get" action="/Contact">
              <button type="submit">Send Response</button>
              </form>
              
                            
                        </div>
                            </form>
                    
                </div>
            </div>
          
        );
    }
}

export default Contact;