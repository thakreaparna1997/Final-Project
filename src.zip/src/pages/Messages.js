import React, { Component } from "react";
import "./as.css";


const nameRegex = RegExp(
    /^[a-zA-Z]*$/
);



const formValid = ({ formErrors, ...rest }) => {
    let valid = true;

    // validate form errors being empty
    Object.values(formErrors).forEach(val => {
        val.length > 0 && (valid = false);
    });

    // validate the form was filled out
    Object.values(rest).forEach(val => {
        val === null && (valid = false);
    });

    return valid;
};

class Messages extends Component {
    constructor(props) {
        super(props);

        this.state = {
            firstName: null,
            

            formErrors: {
                firstName: "",
                

            }
        };
    }

    handleSubmit = e => {
        e.preventDefault();

        if (formValid(this.state)) {
            console.log(`
        --SUBMITTING--
        First Name: ${this.state.firstName}
        
      `);
        } else {
            console.error("FORM INVALID - DISPLAY ERROR MESSAGE");
        }
    };

    handleChange = e => {
        e.preventDefault();
        const { name, value } = e.target;
        let formErrors = { ...this.state.formErrors };

        switch (name) {
            case "firstName":
                formErrors.firstName =nameRegex.test(value)&&value.length > 2
                ? ""
                : "invalid firstname address";
                break;
            

            default:
                break;
        }

        this.setState({ formErrors, [name]: value }, () => console.log(this.state));
    };

    render() {
        const { formErrors } = this.state;

        return (
          
           
                <div className="body1">
                <div className="form-wrapper">
                    <h1>Post your Doubts here</h1>
                    <form onSubmit={this.handleSubmit} noValidate>
                        <div className="firstName">
                            <label htmlFor="firstName">Query Title</label>
                            <input
                                className={formErrors.firstName.length > 0 ? "error" : null}
                                
                                type="text"
                                name="firstName"
                                noValidate
                                onChange={this.handleChange}
                            />
                            {formErrors.firstName.length > 0 && (
                                <span className="errorMessage">{formErrors.firstName}</span>
                            )}
                        </div>
                        
                        <div className="password">
                            <label htmlFor="password"> Message</label>
                            <textarea placeholder="Write Your Message Here"></textarea>
                        </div>
                        <div className="createAccount">
                        <form method="get" action="/Contact">
              <button type="submit">Send</button>
              </form>
              
                            
                        </div>
                            </form>
                    
                </div>
            </div>
            
        );
    }
}

export default Messages;
