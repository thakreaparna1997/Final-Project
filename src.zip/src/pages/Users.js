import React from 'react';
import "./as.css";
function Users() {
  return (
    <div className='Users'>
      <h1>Admin User Page</h1>
    </div>
  );
}

export default Users;