import React from 'react';
import "./as.css";
function FeedbackAdmin() {
  return (
    <div className='FeedbackAdmin'>
      <h1>Admin Feedback Page</h1>
    </div>
  );
}

export default FeedbackAdmin;
