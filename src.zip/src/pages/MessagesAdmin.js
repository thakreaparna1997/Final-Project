import React from 'react';
import "./as.css";
function MessagesAdmin() {
  return (
    <div className='MessagesAdmin'>
      <h1>Admin Messages Page</h1>
    </div>
  );
}

export default MessagesAdmin;
