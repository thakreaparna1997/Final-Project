// import React from 'react';
// import "./as.css";

import "./as.css";
import React, { Component } from 'react'
import ScheduleService from '../Services/ScheduleService';

class Quiz extends Component {
  constructor(props){
      super(props)

      this.state={
             schedules:[]
      }
      
  }
  componentDidMount(){
    ScheduleService.getSchedule().then((res)=>{
       this.setState({schedules: res.data });
    });  
  }


render()  {
  return (
    // <div className='quiz'>
    //   <h1>Quiz</h1>
    // </div>
    <div>
      <div className="row">
        <div className="col-3"></div>
        <div className="col-6 my-2">
          <div className="bg-dark p-4 text-light rounded d-flex justify-content-between align-items-center">
            <div>Recording List</div>
            <button className="btn btn-secondary" >
            {/* <button className="btn btn-secondary" onClick={addUser}> */}
              Add Recording
            </button>
          </div>
        </div>
      </div>

      {/* {userList.map((item, index) => ( */}
        {/* <div className="row" key={index}> */}
        <div className="row" >
          <div className="col-3"></div>
          <div className="col-6">
            {/* <div
              className="alert alert-secondary d-flex justify-content-between align-items-center"
              key={index}
            > */}
            <div
              className="alert alert-secondary d-flex justify-content-between align-items-center"
              
            >
              <div>
                {/* {index + 1}.<span className="ml-2">{item.username}</span> */}
                <span className="ml-2">
                  <table>
                  <tbody>
                         {
                           this.state.schedules.map(
                               schedule=>
                               <tr key={schedule.id}>
                                  
                                  <td>{schedule.topicName}</td>
                                  <td>{schedule.date}</td>
                                  <td>{schedule.time}</td>
                                  <td>{schedule.meetingId}</td>
                                  <td>{schedule.password}</td> 
                                  {/* <a href={recording.link} target={"_blank"}><button type="button" class="btn btn-primary">Access Here</button></a> */}
                               </tr>
                           )  
                         }
                       </tbody>  
                  </table>
                </span> 
              </div>
              <div>
                <button className="btn btn-sm btn-secondary">Edit </button>
                {/* <button
                  className="btn btn-sm btn-danger"
                  onClick={() => deleteUser(item)}
                >
                  
                  Delete{" "}
                </button> */}
                 <button
                  className="btn btn-sm btn-danger"
                  
                >
                  
                  Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      ))
    </div>
  );
}
}


export default Quiz;
