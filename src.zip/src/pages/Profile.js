import React from 'react';
import "./as.css";
function Profile() {
  return (
    <div className='profile'>
      <h1>Profile</h1>
    </div>
  );
}

export default Profile;
