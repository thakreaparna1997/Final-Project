import React from 'react';
import "./as.css";

function Feedback() {
  return (
    <div className="container">
       <div>
      <h2 className="text-center">Employee List</h2>
      <div className="row">
        <table className="table table-striped table-bordered">

            <thead>
               <tr>
                  <th>Employee First Name</th>
                  <th>Employee Last Name</th>
                  <th>Employee Email Id</th>
                  <th>Actions with button</th>
               </tr>

            </thead>
             
            {/* <tbody>
              {

                this.state.employees.map(
                  employee=>
                <tr key ={employee.id}>
                  <td>{employee.firstName}</td>

                </tr>
                )


              }
            </tbody> */}

        </table>
      </div>
    </div>
    </div>
  );
}

export default Feedback;
