import React from 'react';

function HomeAdmin() {
  return (
    <div className='homeadmin'>
      <h1>Admin Homepage</h1>
    </div>
  );
}

export default HomeAdmin;
