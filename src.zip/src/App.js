import { useState } from 'react';
import { Carousel } from "react-bootstrap";
import { BrowserRouter as Router,Route,Link, useLocation, useHistory } from 'react-router-dom';
import './App.css';
import './Board.css';
import Homepage1 from "./Homepage1";
import Admin from "./Admin";
import Card from 'react-bootstrap/Card'
import Button from 'react-bootstrap/Button'
import Image from 'react-bootstrap/Image'
import Container from 'react-bootstrap/Container'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'

import shu1 from "./Component/JAVA.jpeg";
import shu2 from "./Component/OS.jpeg";
import shu3 from "./Component/SE.jpeg";
import shu4 from "./Component/OOPS.jpeg";
import shu5 from "./Component/DS.jpeg";
import shu6 from "./Component/DB.jpeg";
import shu7 from "./Component/WEB.jpeg";
import shu8 from "./Component/WEBJAVA.jpeg";
import hu2 from "./pages/Aboutimg.jpg";
import pranit from "./pages/Pranit.jpg";



function App() {
  const location=useLocation();
  console.log(location);
  return (
    <>
    
     {!["/login","/signup","/","/loginAsAdmin"].includes(location.pathname) &&(
       <>
        <div  >
          {
            
         // <Link to="/Homepage1" className=" mr-3 ">Home</Link>
          /* <Link to="/home" className=" mr-3 ">Home</Link>
          <Link to="/quiz" className=" mr-3 ">Quiz</Link>
          <Link to="/feedback" className=" mr-3 ">Feedback</Link>
          <Link to="/messages" className=" mr-3 ">Messages</Link>
          <Link to="/recording" className=" mr-3 ">Recording</Link>
          <Link to="/schedule" className=" mr-3 ">Scheduled</Link>
          <Link to="/profile" className=" mr-3 ">Profile</Link>
          <Link to="/contactus" className=" mr-3 ">ContactUs</Link> */}
        </div>
       </>
     )}
     
     {!["/home","/quiz","/feedback","/messages","/recording","/schedule","/profile","/contactus","/Homepage1","/Admin"].includes(location.pathname) &&(
       <>
        {/* <Link to="/signup" className="mr-3">Signup</Link>
        <Link to="/login" className="mr-3">Login As Student</Link>
        <Link to="/loginAsAdmin" className="mr-3">Login As Admin</Link> */}
       </>
     )}
     

     
     
     <Route exact path="/login" component={Login}/>
      <Route path="/signup" component={Signup}/>

      <Route path="/Homepage1" component={Homepage1}/>
      <Route path="/Admin" component={Admin}/>
      <Route exact path="/" component={Demo}/>
      <Route path="/loginAsAdmin" component={LoginAsAdmin}/>
      {/* <Route path="/home" component={Home}/>
      <Route path="/quiz" component={Quiz}/>
      <Route path="/feedback" component={Feedback}/> 
      <Route path="/messages" component={Messages}/>          
      <Route path="/recording" component={Recording}/>          
      <Route path="/schedule" component={Schedule}/>          
      <Route path="/profile" component={Profile}/>
      <Route path="/contact" component={Contact}/> */}
      
  </>
  );
}

function Demo(){
  return(
    <div >
      <body class="text-center " style={{backgroundColor:"black",height:"100%"}}>
      <div class="cover-container d-flex h-100 p-3 mx-auto flex-column">
      <header class="masthead mb-auto">
        <div class="inner">
        
          <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark ">
          {/* <div class="board">
        <span>D</span>
        <span>A</span>
        <span>C</span>
        <span>-</span>
        <span>B</span>
        <span>O</span>
        <span>A</span>
        <span>R</span>
        <span>D</span>
        </div> */}
          <h3 class="masthead-brand text-secondary ">DAC-BOARD</h3> 

            <a class="nav-link active " href="/signup">Register</a>
            <a class="nav-link" href="/login">Student Login</a>
            <a class="nav-link" href="/loginAsAdmin ">Admin Login</a>
            
          </nav>
          
      </div>
      </header>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <OurMoto/>
      
      <Course />
      <br></br>
      <br></br>
      <Event1RowInfo/>
      <br></br>
      <Event2RowInfo/>
      <br></br>
      <br></br>
      <OurTeamHeader/>
      <TeamInfo1/>
      <br></br>
      
      <br></br>
      <br></br>
      <About />

      
      <footer class="mastfoot mt-auto">
        <div class="inner">
          <p>Cover template for <a href="https://getbootstrap.com/">Bootstrap</a>, by <a href="https://twitter.com/mdo">@mdo</a>.</p>
        </div>
      </footer>
      </div>
      </body>
    </div>
  );
}

function Event1RowInfo(){
  return(
    <div className="row ">
      <div className="d-none d-md-block col-md-2  "></div>
      <div className="col-12 col-md-8 d-flex justify-content-between ">
        <Card1/>
        <Card2/>
        <Card3/>
        <Card4/>
      </div>
      <div className="d-none d-md-block col-md-2 "></div>
    </div>
  );
}
function Event2RowInfo(){
  return(
    <div className="row ">
      <div className="d-none d-md-block col-md-2  "></div>
      <div className="col-12 col-md-8 d-flex justify-content-between ">
        <Card5/>
        <Card6/>
        <Card7/>
        <Card8/>
      </div>
      <div className="d-none d-md-block col-md-2 "></div>
    </div>
  );
}

function Card1(){
  return(
    <div className="card mr-3" style={{width:"18rem"}}>
    <img src={shu1} className="card-img-top" alt="..."></img>
    <div className="card-body">
      <h5 className="card-title ">JAVA</h5>
      
      <a href="#"><button  className="btn btn-primary col-12  ">Get Started</button></a>
    </div>
    </div>
  );
}
function Card2(){
  return(
    <div className="card mr-3" style={{width:"18rem"}}>
    <img src={shu2} className="card-img-top" alt="..."></img>
    <div className="card-body">
      <h5 className="card-title">OPERATING SYSTEM</h5>
     
      <a href="#" className="btn btn-primary col-12">Get Started</a>
    </div>
    </div>
  );
}
function Card3(){
  return(
    <div className="card mr-3" style={{width:"18rem"}}>
    <img src={shu3} className="card-img-top" alt="..."></img>
    <div className="card-body">
      <h5 className="card-title">SOFTWARE ENGINEERING</h5>
     
      <a href="#" className="btn btn-primary col-12">Get Started</a>
    </div>
    </div>
  );
}
function Card4(){
  return(
    <div className="card mr-3" style={{width:"18rem"}}>
    <img src={shu4} className="card-img-top" alt="..."></img>
    <div className="card-body">
      <h5 className="card-title">OOPS CONCEPT JAVA</h5>
     
      <a href="#" className="btn btn-primary col-12">Get Started</a>
    </div>
    </div>
  );
}
function Card5(){
  return(
    <div className="card mr-3" style={{width:"18rem"}}>
    <img src={shu5} className="card-img-top" alt="..."></img>
    <div className="card-body">
      <h5 className="card-title">ALGORITHMS AND DATA STRUCTURE </h5>
      
      <a href="#" className="btn btn-primary col-12">Get Started</a>
    </div>
    </div>
  );
}
function Card6(){
  return(
    <div className="card mr-3" style={{width:"18rem"}}>
    <img src={shu6} className="card-img-top" alt="..."></img>
    <div className="card-body">
      <h5 className="card-title">DATABASE TECHNOLOGY</h5>
      
      <a href="#" className="btn btn-primary col-12">Get Started</a>
    </div>
    </div>
  );
}
function Card7(){
  return(
    <div className="card mr-3" style={{width:"18rem"}}>
    <img src={shu7} className="card-img-top" alt="..."></img>
    <div className="card-body">
      <h5 className="card-title">WEB PROGRAMMING TECHNOLOGY</h5>
      
      <a href="#" className="btn btn-primary col-12">Get Started</a>
    </div>
    </div>
  );
}
function Card8(){
  return(
    <div className="card mr-3" style={{width:"18rem"}}>
    <img src={shu8} className="card-img-top" alt="..."></img>
    <div className="card-body">
      <h5 className="card-title">WEB-BASED JAVA PROGRAMMING </h5>
     
      <a href="#" className="btn btn-primary col-12">Get Started</a>
    </div>
    </div>
  );
}
function OurMoto(){
  return(
    <div>
      <div class="container" >
      <div class="jumbotron mt-3" style={{backgroundColor:"black"}}>
        <h1 className="card-title d-flex justify-content-center " class="text-light" 
        style={{fontSize:"2rem",fontWeight:'bold',marginBottom:"20px",text:"light"}}>Our Aims </h1>
        <p className="card-text" class="text-light" style={{textAlign:"center",fontSize:"20px" ,text:"white"}}> Learn anytime, anywhere
              Our Application provides the learner to access their lectures through recorded videos,can apply on quiz and test their skills
              ,post their doubts, and view their improvemnt.Delivering customized learning based on the student's learning .No need to travel, learn at the comfort & safety of your home 
        </p>
        
      </div>
    </div>
         
    </div>
    
  );
}
function TeamInfo1(){
  return(
    <div class="d-flex justify-content-center">

    <Carousel>
        <Carousel.Item interval={1500}>
          
        <img className="rounded-circle" 
         
         src="https://source.unsplash.com/300x300/?learning"
            alt="First slide"
          />
          <Carousel.Caption>
            <h4>Aparna Thakre</h4>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item interval={1500}>
        <img className="rounded-circle"
         
         src="https://source.unsplash.com/300x300/?education"
            alt="Second slide"
          />
          <Carousel.Caption>
            <h4>Shubham Sawake</h4>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item interval={1500}>
        <img className="rounded-circle"
         
         src="https://source.unsplash.com/300x300/?teaching"
            alt="Third slide"
          />
          <Carousel.Caption>
            <h4>Swapnil Andhale</h4>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item interval={1500}>
          <img className="rounded-circle"
         
            src={pranit}
            alt="Fourth slide"
          />
          <Carousel.Caption>
            <h4>Pranit Gundare</h4>
          </Carousel.Caption>
        </Carousel.Item>

        <Carousel.Item interval={1500}>
        <img className="rounded-circle"
         
         src="https://source.unsplash.com/300x300/?knowledge"
            alt="Fifth slide"
          />
          <Carousel.Caption>
            <h4>Nitin Gaikwad</h4>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item interval={1500}>
        <img className="rounded-circle"
         
         src="https://source.unsplash.com/300x300/?teaching"
            alt="sixth  slide"
          />
          <Carousel.Caption>
            <h4>Ajinkya Surashe</h4>
          </Carousel.Caption>
        </Carousel.Item>

      </Carousel>
</div>
  );
}

function OurTeamHeader(){
  return(
    <h5 className="card-title d-flex justify-content-center " class="text-light" 
    style={{fontSize:"2rem",fontWeight:'bold',marginBottom:"20px",text:"white"}}>Our Team</h5>
  );
}

function About(){
  return(
    
    <div class="row">
      <div class="col-xs-12 col-md-6"><img src={hu2} class="img-responsive" alt="website template image" /></div>
      <div class="col-xs-12 col-md-6">
        <div class="about-text">
          <h2 class="text-light" style={{fontSize:"2rem",fontWeight:'bold',marginBottom:"20px",text:"white"}}>About Us</h2>
          <p class="text-light" style={{textAlign:"center",fontSize:"20px" ,text:"white"}}>We are focused on a proper utilised  system for Distance Learning using innovative technology as a significance tool to drive quality of education. 
And improvising learning process with effective interaction and management of the studies.Student may find it useful to maintain 
their aspect towards discipline in their learning and more interesting for making their future secure with the better experience.
</p>
          {/* <h3 class="text-light" style={{fontSize:"2rem",fontWeight:'bold',marginBottom:"20px",text:"white"}}>Why Choose Us?</h3>
          <div class="list-style">
            <div class="col-lg-6 col-sm-6 col-xs-12 text-light" style={{text:"white"}}>
              <ul>
                <li>Lorem ipsum dolor</li>
                <li>Tempor incididunt</li>
                <li>Lorem ipsum dolor</li>
                <li>Incididunt ut labore</li>
              </ul>
            </div>
            <div class="col-lg-6 col-sm-6 col-xs-12 text-light" style={{text:"white"}}>
              <ul>
                <li>Aliquip ex ea commodo</li>
                <li>Lorem ipsum dolor</li>
                <li>Exercitation ullamco</li>
                <li>Lorem ipsum dolor</li>
              </ul>
            </div> */}
          </div>
        </div>
      </div>
    

    
  );
}
function Course(){
  return(
    <h3    class="text-light" style={{fontSize:"2rem",fontWeight:'bold',marginBottom:"20px",text:"white"}}>Course Highlights</h3>

    
  );
}
// function Home(){
//   const history=useHistory();
//   const signOut=()=>{
//     history.push=("/login");
//   }
//   return(
//     <div className="bg-dark" style={{height:"100vh"}}>
//       <h3>Home page</h3>
//     </div>
//   );    
// }

// function Quiz(){
//   return(
//     <div className="bg-success" style={{height:"100vh"}} >Quiz page</div>
//   );    
// }

// function Feedback(){
//   return(
//     <div className="bg-danger" style={{height:"100vh"}} >Feedback page</div>
//   );    
// }

// function Messages(){
//   return(
//     <div className="bg-danger" style={{height:"100vh"}} >Message page</div>
//   );    
// }

// function Recording(){
//   return(
//     <div className="bg-danger" style={{height:"100vh"}} >Recording Page</div>
//   );    
// }

// function Schedule(){
//   return(
//     <div className="bg-danger" style={{height:"100vh"}} >Schedule Page</div>
//   );    
// }

// function Profile(){
//   return(
//     <div className="bg-danger" style={{height:"100vh"}} >Profile Page</div>
//   );    
// }

// function ContactUs(){
//   return(
//     <div className="bg-danger" style={{height:"100vh"}} >ContactUs Page</div>
//   );    
// }

function LoginAsAdmin(){
  const history=useHistory();
  const[user,setUser]=useState({
    username:"",
    password:"",
    
  });

  const processLogin1=()=>{
    /*if(user.username === ''|| user.password===''){
      alert("Invalid/empty field");
      return;
    }*/
       history.push("/Admin");
  }
  const gotoRegister1=()=>{
    history.push("/signup");
}

const syncUsername1=(e)=>{setUser({...user,username:e.target.value})}
 
const syncPassword1=(e)=>{ setUser({...user,password:e.target.value})}

  return(
   <div className="container">
      <div className="bg-warning" style={{height:"100vh"}}>
      <h3>Welcome to Admin Page</h3>

      <div>
       Username<input type="text" name="username" onChange={syncUsername1}/>
      </div>
      <div>
       Password<input type="password" name="username"onChange={syncPassword1}/>
      </div>
      <div>
       <button onClick={processLogin1}>Login</button>
      </div>
      <div>
      <button onClick={gotoRegister1}>Go to Register</button>
      </div>
      
      
    </div>
   </div>
  );
}

function Login(){

  let history=useHistory();
  const handleClick = ()=>{
     history.push("/Signup");
};
const processLogin=()=>{
  /*if(user.username === ''|| user.password===''){
    alert("Invalid/empty field");
    return;
  }*/
     history.push("/Homepage1");
}
  return (
    <div className="loginbody">
<div className="container-fluid">
  <div className="login">

  

<h1 className="mb-2"><u>Login</u></h1>

<div class="form-group row">
  <label for="colFormLabel" class="col-sm-2 col-form-label">Username</label>
  <div class="col-sm-10">
    <input type="username" class="form-control" id="colFormLabel" placeholder="Enter Username"></input>
  </div>
  </div>

<div class="form-group row">
  <label for="colFormLabel" class="col-sm-2 col-form-label">Password</label>
  <div class="col-sm-10">
    <input type="password" class="form-control" id="colFormLabel" placeholder="Enter Password"></input>
  </div>
  </div>
 <br></br>
<button class="btn btn-outline-info mt-2" onClick={processLogin}>Login</button>
<br></br>
<div><button class="btn btn-outline-info mt-2" onClick={handleClick}>Register</button></div>
<h7>Register here..If you are a new user.!</h7>
</div>
</div>
</div>
  );
}


function Signup(){
  let history=useHistory();
     const handleClick = ()=>{
        history.push("/login");
   };
   
   return (
<div className="loginbody">
   <div className="container-fluid">
   <div className="register">

   

   <h1 className="mb-2"><u>Registration</u></h1>
  
   <div class="form-group row">
   <label for="colFormLabel" class="col-sm-2 col-form-label">UserId</label>
   <div class="col-sm-10">
     <input type="text" class="form-control" id="colFormLabel" placeholder="Enter ID"></input>
   </div>
   </div>

   
   <div class="form-group row">
   <label for="colFormLabel" class="col-sm-2 col-form-label">Username</label>
   <div class="col-sm-10">
     <input type="username" class="form-control" id="colFormLabel" placeholder="Enter Username"></input>
   </div>
   </div>

   <div class="form-group row">
   <label for="colFormLabel" class="col-sm-2 col-form-label">Password</label>
   <div class="col-sm-10">
     <input type="password" class="form-control" id="colFormLabel" placeholder="Enter Password"></input>
   </div>
   </div>
   
   <div class="form-group row">
   <label for="colFormLabel" class="col-sm-2 col-form-label">DOB</label>
   <div class="col-sm-10">
     <input type="text" class="form-control" id="colFormLabel" placeholder="Enter Date Of Birth"></input>
   </div>
   </div>
 
   <div class="form-group row">
   <label for="colFormLabel" class="col-sm-2 col-form-label">Email</label>
   <div class="col-sm-10">
     <input type="email" class="form-control" id="colFormLabel" placeholder="Enter Email"></input>
   </div>
   </div>
 
   
  
   <button class="btn btn-outline-info mt-2" onClick={handleClick}>Register</button>
   
   <div><button class="btn btn-outline-info mt-2" onClick={handleClick}>Login</button></div>
   </div>
   </div>
   </div>

   );
}
export default App;